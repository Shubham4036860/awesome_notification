import 'package:flutter/material.dart';

class ProductDetailPage extends StatefulWidget {
  String productImageUrl;
  String productTitle;
  String productDescription;

  ProductDetailPage(
      this.productImageUrl, this.productTitle, this.productDescription,
      {super.key});

  @override
  State<ProductDetailPage> createState() => _ProductDetailPageState();
}

class _ProductDetailPageState extends State<ProductDetailPage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.only(top: 20.0, left: 20.0),
            child: Text(
              'Product Detail',
              style: TextStyle(
                  color: Colors.orange,
                  fontSize: 18,
                  fontWeight: FontWeight.w500),
            ),
          ),
          productDetailsView(widget.productImageUrl, widget.productTitle,
              widget.productDescription)
        ],
      ),
    ));
  }

  Widget productDetailsView(
      String urlOfProduct, String titleOfProduct, String desOfProduct) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 20.0),
          child: SizedBox(
            height: MediaQuery.of(context).size.height * 0.3,
            width: MediaQuery.of(context).size.width,
            child: Image.network(urlOfProduct, fit: BoxFit.contain),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 20.0,left: 20.0),
          child: Text(
            titleOfProduct,
            style: const TextStyle(
                color: Colors.orange, fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 10.0,left: 20.0),
          child: Text(
            desOfProduct,
            style: const TextStyle(
                color: Colors.grey, fontSize: 14, fontWeight: FontWeight.w500),
          ),
        ),
      ],
    );
  }
}
