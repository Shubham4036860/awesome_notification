import 'package:awesome_notification_tutorial/notificationUtils/notification_utils.dart';
import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:flutter/material.dart';

class HomeView extends StatefulWidget {
  const HomeView({super.key});

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  bool checkPermissionExist = false;

  NotificationUtils notificationUtils = NotificationUtils();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: true,
      bottom: true,
      child: Scaffold(
        body: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.only(top: 20.0, left: 20.0),
              child: Text(
                'Awesome Notification',
                style: TextStyle(
                    color: Colors.orange,
                    fontSize: 18,
                    fontWeight: FontWeight.w500),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 20.0, left: 20, right: 20),
              child: notificationType(),
            ),
            /*Padding(
              padding: const EdgeInsets.only(top: 20.0, left: 20, right: 20),
              child: permissionButton(context),
            ),*/
          ],
        ),
      ),
    );
  }

  Widget notificationType() {
    return SizedBox(
      child: GridView.extent(
        primary: false,
        shrinkWrap: true,
        // padding: const EdgeInsets.all(16),
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        maxCrossAxisExtent: 200.0,
        children: <Widget>[
          GestureDetector(
            onTap: () {
              print("check to click this method");
              // notificationUtils.createNewNotification();
              notificationUtils.createNewNotification12();

            },
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: const [
                    BoxShadow(
                      offset: Offset(0, 0),
                      blurRadius: 1,
                      color: Color.fromRGBO(0, 0, 0, 0.10),
                    )
                  ],
                  border: Border.all(color: Colors.orange, width: 0.5)),
              child: const Center(
                child: Text('Instant Notification',
                    style: TextStyle(
                        fontSize: 20,
                        color: Colors.black,
                        fontWeight: FontWeight.bold)),
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                boxShadow: const [
                  BoxShadow(
                    offset: Offset(0, 0),
                    blurRadius: 1,
                    color: Color.fromRGBO(0, 0, 0, 0.10),
                  )
                ],
                border: Border.all(color: Colors.orange, width: 0.5)),
            child: const Center(
              child: Text('Schedule Notification',
                  style: TextStyle(
                      fontSize: 20,
                      color: Colors.black,
                      fontWeight: FontWeight.bold)),
            ),
          ),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                boxShadow: const [
                  BoxShadow(
                    offset: Offset(0, 0),
                    blurRadius: 1,
                    color: Color.fromRGBO(0, 0, 0, 0.10),
                  )
                ],
                border: Border.all(color: Colors.orange, width: 0.5)),
            child: const Center(
              child: Text('From Json Notification',
                  style: TextStyle(
                      fontSize: 20,
                      color: Colors.black,
                      fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  Widget permissionButton(BuildContext context) {
    return GestureDetector(
      onTap: () => checkPermissionExist == false
          ? checkingPermissionNotification()
          : null,
      child: Container(
        width: MediaQuery.of(context).size.width * 0.9,
        height: 52,
        color: checkPermissionExist == true ? Colors.green : Colors.red,
        child: Center(
            child: Text(
          checkPermissionExist == true
              ? "Permission Already Granted"
              : "Click To grant Notification Permission",
          style:
              const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        )),
      ),
    );
  }

  @override
  void initState() {
    checkingPermissionNotification();
    super.initState();
  }

  void checkingPermissionNotification() {
    AwesomeNotifications().isNotificationAllowed().then(
      (isAllowed) {
        if (!isAllowed) {
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: const Text('Allow Notifications'),
              content:
                  const Text('Our app would like to send you notifications'),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: const Text(
                    'Don\'t Allow',
                    style: TextStyle(color: Colors.grey, fontSize: 18),
                  ),
                ),
                TextButton(
                  onPressed: () => AwesomeNotifications()
                      .requestPermissionToSendNotifications()
                      .then((value) {
                    if (value == true) {
                      setState(() {
                        checkPermissionExist = true;
                      });
                    }
                    Navigator.pop(context);
                  }),
                  child: const Text(
                    'Allow',
                    style: TextStyle(
                      color: Colors.orange,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          );
        }
      },
    );
  }
}
