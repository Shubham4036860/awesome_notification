import 'dart:isolate';
import 'dart:math';
import 'dart:ui';

import 'package:awesome_notification_tutorial/main.dart';
import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;


class NotificationUtils {
  static ReceivedAction? initialAction;



  NotificationUtils._();

  factory NotificationUtils() => _instance;
  static final NotificationUtils _instance = NotificationUtils._();
  final AwesomeNotifications awesomeNotifications = AwesomeNotifications();

   Future<void> configuration() async {
    print("configuration check with this");
    await awesomeNotifications.initialize(
        null,
        [
          NotificationChannel(
            channelKey: 'basic_channel',
            channelName: 'Basic Notifications',
            defaultColor: Colors.teal,
            importance: NotificationImportance.High,
            channelShowBadge: true,
            channelDescription: 'Basic Instant Notification',
          ),
        ],
        debug: true);
  }

  Future<void> instantNotification() async {
    /*File file = File('assets/images/hoodie_Images.jpeg');
    if (file.existsSync()) {
      // File exists
      // Create notification with bigPicture
      print("file is found hurry");

      await AwesomeNotifications().createNotification(
          content: NotificationContent(
              id: Random().nextInt(100),
              // id: id,
              channelKey: 'basic_channel',
              title: 'Buy Favorite Product',
              body: 'Hurry Up To Grab This Product Loot With Just 80% Off ',
              // bigPicture: file.path,
              icon: 'android/app/src/main/res/mipmap-hdpi/ic_launcher.png',
              notificationLayout: NotificationLayout.BigPicture));
    } else {
      // File doesn't exist
      // Handle the error
      print("file is not found");
    }*/
    await awesomeNotifications.createNotification(
      content: NotificationContent(
        id: Random().nextInt(100),
        channelKey: 'basic_channel',
        title: 'Awesome Notification',
        body: 'This is an awesome notification!',
        icon: 'android/app/src/main/res/mipmap-hdpi/ic_launcher.png',
        notificationLayout: NotificationLayout.Default,
      ),
    );
  }

  Future<void> createNewNotification12() async {
    bool isAllowed = await AwesomeNotifications().isNotificationAllowed();
    if (!isAllowed) isAllowed = await displayNotificationRationale();
    if (!isAllowed) return;

    await AwesomeNotifications().createNotification(
        content: NotificationContent(
            id: -1,
            // -1 is replaced by a random number
            channelKey: 'basic_channel',
            title: 'Huston! The eagle has landed!',
            body:
                "A small step for a man, but a giant leap to Flutter's community!",
            bigPicture: 'https://storage.googleapis.com/cms-storage-bucket/d406c736e7c4c57f5f61.png',
            largeIcon: 'https://storage.googleapis.com/cms-storage-bucket/0dbfcc7a59cd1cf16282.png',
            //'asset://assets/images/balloons-in-sky.jpg',
            notificationLayout: NotificationLayout.BigPicture,
            payload: {'notificationId': '1234567890'}),
        actionButtons: [
          NotificationActionButton(key: 'REDIRECT', label: 'Redirect'),
          NotificationActionButton(
              key: 'REPLY',
              label: 'Reply Message',
              requireInputText: true,
              actionType: ActionType.SilentAction),
          NotificationActionButton(
              key: 'DISMISS',
              label: 'Dismiss',
              actionType: ActionType.DismissAction,
              isDangerousOption: true)
        ]);
  }

  static Future<bool> displayNotificationRationale() async {
    bool userAuthorized = false;
    BuildContext context = MyApp.navigatorKey.currentContext!;
    await showDialog(
        context: context,
        builder: (BuildContext ctx) {
          return AlertDialog(
            title: Text('Get Notified!',
                style: Theme.of(context).textTheme.titleLarge),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Image.asset(
                        'assets/images/animated-bell.gif',
                        height: MediaQuery.of(context).size.height * 0.3,
                        fit: BoxFit.fitWidth,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                const Text(
                    'Allow Awesome Notifications to send you beautiful notifications!'),
              ],
            ),
            actions: [
              TextButton(
                  onPressed: () {
                    Navigator.of(ctx).pop();
                  },
                  child: Text(
                    'Deny',
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(color: Colors.red),
                  )),
              TextButton(
                  onPressed: () async {
                    userAuthorized = true;
                    Navigator.of(ctx).pop();
                  },
                  child: Text(
                    'Allow',
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(color: Colors.deepPurple),
                  )),
            ],
          );
        });
    return userAuthorized &&
        await AwesomeNotifications().requestPermissionToSendNotifications();
  }
}
